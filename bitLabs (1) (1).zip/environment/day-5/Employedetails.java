class employe{
    String ename
}