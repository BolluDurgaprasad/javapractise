class hello{
    public static void main(String[]args){
        int rollno=123;
        String name="durga";
        String branch="mech";
        System.out.println("name="+name+"\nrollno="+rollno+"\nbranch="+branch);
    }
}