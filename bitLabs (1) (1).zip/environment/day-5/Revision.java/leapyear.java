public class leapyear{
    public static void main(String[]args){
        System.out.println("\n.....leapyear.....\n(year=2020)");
        int year=2020;
        if((year % 4==0)&&(year % 100!=0))
        System.out.println("Entered year is a leap year");
        else if(year%400 == 0)
        System.out.println("Entered year is leap year" );
        else
        System.out.println("Entered year is year is not a leap year");
    }
}