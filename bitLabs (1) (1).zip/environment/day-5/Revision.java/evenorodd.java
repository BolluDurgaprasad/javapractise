public class evenorodd{
    public static void main(String[] args){
        System.out.println("\n......even/odd number....\n(num=10)");
        int num=10;
        if(num%2==0)
        System.out.println(num + "is even");
        else
        System.out.println(num + "is odd");
    }
}