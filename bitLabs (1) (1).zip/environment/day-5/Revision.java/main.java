class main{
    public static void main(String[] args){
        int a=7,b=3,c=a+b;
        System.out.println("Sumoftwonumbers"+c);
    }
}