class intrest{
    public static void main(String[]args){
        int p=1000,q=12,r=2;
        int si=(p*q*r)/100;
        System.out.println("simple intrest si"+si);
    }
}