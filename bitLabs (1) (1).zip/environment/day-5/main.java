class Student{
    int rollno;
    String name;
    String section;
    int marks;
    String address;
    void reading()
    {
        System.out.println(name+"reading");
    }
    void writing()
    {
        System.out.println(name+"Writing");
    }
}
class main
{
    public static void main(String args[]){
        Student std1=new Student();
        std1.rollno=7;
        std1.name="durgaprasad";
        std1.section="mech-A";
        std1.marks=75;
        std1.address="vizag";
        System.out.println("Student information");
        System.out.println("std1.rollno+std1.name+std1.section+std1.marks+std1.address");
        std1.reading();
        std1.writing();
        Student std2=new Student();
        std2.rollno=7;
        std2.name="naga";
        std2.section="mech-b";
        std2.marks=85;
        std2.address="vzm";
        System.out.println("Student information");
        System.out.println("std2.rollno+std2.name+std2.section+std2.marks+std2.address");
        std2.reading();
        std2.writing();
    }
}