class sumoftwonumbers
{
    public static void main(String[] args)
    {
        int num1=10,num2=20;
        int sum = num1+num2;
        System.out.println(" the sum of 2 numbersb is" + sum);
    }
}