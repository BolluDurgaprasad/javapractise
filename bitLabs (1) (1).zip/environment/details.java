class details
{
    public static void main(String args[])
    {
        System.out.println("Name Bollu Durgaprasad");
        System.out.println("Collge Name vizb");
        System.out.println("Branch Name - Mechanical");
    }
}