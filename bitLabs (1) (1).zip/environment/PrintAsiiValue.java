import java.util.Scanner;
public class PrintAsiiValue
{
    public static void main(String[] args){
        char ch1 = 'a';
        char ch2 = 'b';
        int asiivalues1 = ch1;
        int asiivalues2 = ch2;
        System.out.println(" The asii value of" + ch1 +"is:" +asiivalue 1 );
          System.out.println(" The asii value of" + ch2 +"is:" +asiivalue 2 );
        
    }
}