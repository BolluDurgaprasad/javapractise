import java.utill.Scanner;
public class countevenorodd{
    public static void main(String[] args){
        int i,counteven=0,countodd=0;
        int a[]=new int[100];
        Scanner sc=newScanner(System.in);
        System.out.println("enter array elements");
        for(i=0;i<5;i++)
        {
            a[i]=sc.nextInt();
        }
        for(i=0;i<5;i++)
        {
            if(a[i]%2==0)
            {
                System.out.println("even number"+a[i]);
                counteven++;
            }
            else{
                   System.out.println("odd number"+a[i]);
                   countodd++;
                
            }
        }
          System.out.println("total even number"+counteven);
          System.out.println("total odd number"+counteven);
          
    }
}