public class evenorodd{
public static void main(String[] args){
    int row=sc.nextInt();
    int col=sc.nextInt();
    int a[][]=new int[row][col];
    System.out.println("even elements");
    for(int i=0;i<row;i++)
    {
        for(int j=0;j<col;j++)
        {
            if(a[i][j]%2==0)
            {
                System.out.println(a[i][j]);
            }
        }
    }
    //odd number
    System.out.println("odd numbers");
    for(int i=0;i<row;i++)
    {
        for(intj=0;j<col;j++)
        {
            if(a[i][j]%2!=0){
                System.out.println(a[i][j]);
            }
        }
    }
}